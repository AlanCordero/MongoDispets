﻿using BlazorMongoDB.Data;
using BlazorMongoDB.IService;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BlazorMongoDB.Service
{
    public class ProductService : IProductService
    {
        private readonly IMongoCollection<Product> _productCollection;

        public ProductService()
        {
            var client = new MongoClient("mongodb://127.0.0.1:27017/");
            var database = client.GetDatabase("DispetDB");
            _productCollection = database.GetCollection<Product>("Products");
        }

        public async Task<List<Product>> GetAllProducts()
        {
            return await _productCollection.Find(FilterDefinition<Product>.Empty).ToListAsync();
        }

        public async Task AddProduct(Product product)
        {
            await _productCollection.InsertOneAsync(product);
        }

        public async Task UpdateProduct(Product product)
        {
            await _productCollection.ReplaceOneAsync(p => p.Id == product.Id, product);
        }

        public async Task DeleteProduct(string id)
        {
            await _productCollection.DeleteOneAsync(p => p.Id == id);
        }
        public async Task<List<Product>> GetFeaturedProducts()
        {
            // Asume que los productos destacados tienen la propiedad IsFeatured = true
            return await _productCollection.Find(product => product.IsFeatured).ToListAsync();
        }
        public async Task<Product> GetProductById(string id)
        {
            return await _productCollection.Find(p => p.Id == id).FirstOrDefaultAsync();
        }

    }
}
