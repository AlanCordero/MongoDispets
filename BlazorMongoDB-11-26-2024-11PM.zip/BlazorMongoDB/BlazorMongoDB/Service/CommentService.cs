﻿using BlazorMongoDB.Data;
using BlazorMongoDB.IService;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BlazorMongoDB.Service
{
    public class CommentService : ICommentService
    {
        private readonly IMongoCollection<Comment> _commentCollection;

        public CommentService()
        {
            var client = new MongoClient("mongodb://127.0.0.1:27017/");
            var database = client.GetDatabase("DispetDB");
            _commentCollection = database.GetCollection<Comment>("Comments");
        }

        public async Task<List<Comment>> GetComments()
        {
            return await _commentCollection.Find(FilterDefinition<Comment>.Empty).ToListAsync();
        }

        public async Task AddComment(Comment comment)
        {
            await _commentCollection.InsertOneAsync(comment);
        }
    }
}
