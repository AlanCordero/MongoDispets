﻿using BlazorMongoDB.Data;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BlazorMongoDB.Service
{
    public class OrderService
    {
        private readonly IMongoCollection<Order> _orderCollection;

        public OrderService()
        {
            var client = new MongoClient("mongodb://127.0.0.1:27017/");
            var database = client.GetDatabase("DispetDB");
            _orderCollection = database.GetCollection<Order>("Orders");
        }

        public async Task<List<Order>> GetAllOrders()
        {
            return await _orderCollection.Find(FilterDefinition<Order>.Empty).ToListAsync();
        }

        public async Task AddOrder(Order order)
        {
            await _orderCollection.InsertOneAsync(order);
        }

        public async Task<Order> GetOrderById(string id)
        {
            return await _orderCollection.Find(o => o.Id == id).FirstOrDefaultAsync();
        }
    }
}
