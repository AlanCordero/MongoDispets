﻿using System.Threading.Tasks;
using BlazorMongoDB.Data;
using BlazorMongoDB.IService;
using MongoDB.Driver;

namespace BlazorMongoDB.Service
{
    public class UserService : IUserService
    {
        private readonly IMongoCollection<User> _users;

        // Constructor que inicializa la colección "Users" en la base de datos DispetDB
        public UserService(IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase("DispetDB");
            _users = database.GetCollection<User>("Users");
        }

        public async Task<User> GetUserByUsername(string username)
        {
            return await _users.Find(u => u.Username == username).FirstOrDefaultAsync();
        }

        public async Task AddUser(User user)
        {
            await _users.InsertOneAsync(user);
        }
    }
}
