﻿using System.Collections.Generic;
using System.Linq;
using BlazorMongoDB.Data;

namespace BlazorMongoDB.Service
{
    public class CartService
    {
        private readonly List<Product> cartProducts = new List<Product>();

        public IReadOnlyList<Product> CartProducts => cartProducts.AsReadOnly();

        public void AddProduct(Product product)
        {
            cartProducts.Add(product);
        }

        public void RemoveProduct(Product product)
        {
            cartProducts.Remove(product);
        }

        public void ClearCart()
        {
            cartProducts.Clear();
        }

        public decimal GetTotalPrice()
        {
            return cartProducts.Sum(p => p.Price);
        }
    }
}
